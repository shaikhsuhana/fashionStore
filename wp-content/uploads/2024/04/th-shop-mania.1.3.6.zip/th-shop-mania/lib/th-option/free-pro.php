<div class="th-dashboard">
      <div class="content free-pro">
         <h2>
         <?php esc_html_e('Coming Soon','th-shop-mania'); ?>
         </h2>
      </div>
</div>